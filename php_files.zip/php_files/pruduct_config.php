<?php 
$host = 'snf-870857.vm.okeanos.grnet.gr';
$db = 'hci_app';
$table = 'Item';
$username = 'hci_user';
$password = 'DOoHd8EkdgTFjU2i';
?>
