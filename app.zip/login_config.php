<?php 
$host = 'localhost';
$db = 'hci_app';
$table = 'Users';
$username = 'hci_user';
$password = 'DOoHd8EkdgTFjU2i';
?>
