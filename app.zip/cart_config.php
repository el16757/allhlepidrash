<?php 
$host = 'localhost';
$db = 'hci_app';
$table = 'Cart';
$username = 'hci_user';
$password = 'DOoHd8EkdgTFjU2i';
?>
