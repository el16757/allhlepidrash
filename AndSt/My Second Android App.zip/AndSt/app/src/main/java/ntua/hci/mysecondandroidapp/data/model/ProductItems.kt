package ntua.hci.mysecondandroidapp.data.model

data class ProductItems (
    val itemName: String,
    val storename: String,
    val price: Double
)