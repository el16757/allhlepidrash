package ntua.hci.mysecondandroidapp.data.model

data class CartItems (
    var product: ProductItems,
    var quantity: Int = 0
)